def render_top_view(layout: dict) -> str:
    if layout.get("shape") == "corner":
        return render_corner_top_view(layout)

    scale = 0.25
    margin = 40
    module_depth_mm = 600
    wall_module_depth_mm = 340

    display_length_mm = max(
        layout.get("wall_length_mm", 3000),
        layout.get("used_width_mm", 0),
    )

    width_px = int(display_length_mm * scale) + margin * 2
    height_px = 285

    svg = []
    svg.append(f"<svg xmlns='http://www.w3.org/2000/svg' width='{width_px}' height='{height_px}'>")
    svg.append("<rect width='100%' height='100%' fill='white' />")
    svg.append(f"<text x='{margin}' y='24' font-size='16' font-family='Arial'>Top View</text>")

    base_y = 55
    wall_y = base_y
    wall_h = int(wall_module_depth_mm * scale)
    h = int(module_depth_mm * scale)

    for module in layout.get("modules", []):
        x = margin + int(module["x_mm"] * scale)
        w = int(module["width_mm"] * scale)

        if module["type"] == "profile_handle":
            fill = "#374151"
        elif module["type"] in {"tall", "appliance_tall"}:
            fill = "#cbd5e1"
        elif module["type"] == "freestanding_solo":
            fill = "#fecaca"
        elif module.get("countertop_role") == "free_worktop":
            fill = "#dcfce7"
        elif module.get("countertop_role") == "blocked":
            fill = "#fee2e2"
        else:
            fill = "#e5e7eb"

        svg.append(f"<rect x='{x}' y='{base_y}' width='{w}' height='{h}' fill='{fill}' stroke='black' />")
        if module["type"] == "profile_handle":
            svg.append(
                f"<text x='{x + 3}' y='{base_y + h + 16}' font-size='9' font-family='Arial'>profile</text>"
            )
        else:
            svg.append(
                f"<text x='{x + 6}' y='{base_y + h + 16}' font-size='11' font-family='Arial'>{module['name']}</text>"
            )

    for module in layout.get("wall_modules", []):
        x = margin + int(module["x_mm"] * scale)
        w = int(module["width_mm"] * scale)
        if "hood" in module["name"]:
            fill = "#fca5a5"
        elif "microwave" in module["name"]:
            fill = "#fde68a"
        else:
            fill = "#93c5fd"

        svg.append(
            f"<rect x='{x}' y='{wall_y}' width='{w}' height='{wall_h}' fill='{fill}' fill-opacity='0.72' stroke='#1d4ed8' stroke-width='1.5' />"
        )
        svg.append(
            f"<line x1='{x}' y1='{wall_y + wall_h}' x2='{x + w}' y2='{wall_y + wall_h}' stroke='#1d4ed8' stroke-dasharray='4 3' />"
        )
        door_x = x
        for door_width_mm in module.get("facade_door_widths_mm", [])[:-1]:
            door_x += int(door_width_mm * scale)
            svg.append(
                f"<line x1='{door_x}' y1='{wall_y}' x2='{door_x}' y2='{wall_y + wall_h}' stroke='#1d4ed8' stroke-width='1' />"
            )

    svg.append("</svg>")
    return "".join(svg)


def _module_top_fill(module: dict) -> str:
    if module["type"] == "profile_handle":
        return "#374151"
    if module["type"] in {"tall", "appliance_tall"}:
        return "#cbd5e1"
    if module["type"] == "freestanding_solo":
        return "#fecaca"
    if module.get("corner_module"):
        return "#ddd6fe"
    if module.get("countertop_role") == "free_worktop":
        return "#dcfce7"
    if module.get("countertop_role") == "blocked":
        return "#fee2e2"
    return "#e5e7eb"


def render_corner_top_view(layout: dict) -> str:
    scale = 0.22
    margin = 46
    base_depth_mm = 600
    wall_depth_mm = 340
    side_1_width_mm = layout.get("side_1_width_mm", layout.get("wall_length_mm", 3000))
    side_2_width_mm = layout.get("side_2_width_mm", 2400)
    side_2_corner_at_start = layout.get("side_2", {}).get("corner_position", "left") == "left"
    width_px = int((side_1_width_mm + base_depth_mm) * scale) + margin * 2
    height_px = int((side_2_width_mm + base_depth_mm) * scale) + margin * 2
    origin_x = margin
    origin_y = margin
    corner_at_left = layout.get("corner_position") == "left"
    side_2_x = (
        origin_x
        if corner_at_left
        else origin_x + int(max(0, side_1_width_mm - base_depth_mm) * scale)
    )

    svg = [
        f"<svg xmlns='http://www.w3.org/2000/svg' width='{width_px}' height='{height_px}'>",
        "<rect width='100%' height='100%' fill='white' />",
        f"<text x='{margin}' y='24' font-size='16' font-family='Arial'>Top View - Corner</text>",
    ]

    base_h = int(base_depth_mm * scale)
    wall_h = int(wall_depth_mm * scale)

    for module in layout.get("side_1", {}).get("modules", []):
        x = origin_x + int(module.get("side_x_mm", module.get("x_mm", 0)) * scale)
        y = origin_y
        w = int(module.get("width_mm", 0) * scale)
        svg.append(f"<rect x='{x}' y='{y}' width='{w}' height='{base_h}' fill='{_module_top_fill(module)}' stroke='black' />")
        svg.append(f"<text x='{x + 4}' y='{y + base_h + 14}' font-size='9' font-family='Arial'>{module['name']}</text>")

    for module in layout.get("side_2", {}).get("modules", []):
        x = side_2_x
        module_width_mm = module.get("width_mm", 0)
        module_x_mm = module.get("side_x_mm", module.get("x_mm", 0))
        top_view_y_mm = (
            module_x_mm
            if side_2_corner_at_start
            else side_2_width_mm - module_x_mm - module_width_mm
        )
        y = origin_y + int(top_view_y_mm * scale)
        h = int(module_width_mm * scale)
        svg.append(f"<rect x='{x}' y='{y}' width='{base_h}' height='{h}' fill='{_module_top_fill(module)}' stroke='black' />")
        svg.append(f"<text x='{x + base_h + 6}' y='{y + 14}' font-size='9' font-family='Arial'>{module['name']}</text>")

    for module in layout.get("side_1", {}).get("wall_modules", []):
        x = origin_x + int(module.get("side_x_mm", module.get("x_mm", 0)) * scale)
        y = origin_y
        w = int(module.get("width_mm", 0) * scale)
        svg.append(f"<rect x='{x}' y='{y}' width='{w}' height='{wall_h}' fill='#93c5fd' fill-opacity='0.55' stroke='#1d4ed8' />")

    for module in layout.get("side_2", {}).get("wall_modules", []):
        x = side_2_x
        module_width_mm = module.get("width_mm", 0)
        module_x_mm = module.get("side_x_mm", module.get("x_mm", 0))
        top_view_y_mm = (
            module_x_mm
            if side_2_corner_at_start
            else side_2_width_mm - module_x_mm - module_width_mm
        )
        y = origin_y + int(top_view_y_mm * scale)
        h = int(module_width_mm * scale)
        svg.append(f"<rect x='{x}' y='{y}' width='{wall_h}' height='{h}' fill='#93c5fd' fill-opacity='0.55' stroke='#1d4ed8' />")

    svg.append("</svg>")
    return "".join(svg)


def get_mezzanine_height_mm(layout: dict) -> int:
    if layout.get("mezzanine_enabled") is False:
        return 0

    for module in layout.get("wall_modules", []):
        if module.get("tier") == "mezzanine":
            return int(module.get("height_mm", 0))

    kitchen_height_mm = layout.get("kitchen_height_mm", 2700)
    return max(0, int(round((kitchen_height_mm - 1450) / 3)))


def append_column_section(
    svg: list[str],
    *,
    x: int,
    y: int,
    w: int,
    h: int,
    fill: str,
    label: str,
    size_label: str,
) -> None:
    if h <= 0:
        return

    svg.append(
        f"<rect x='{x}' y='{y}' width='{w}' height='{h}' fill='{fill}' fill-opacity='0.72' stroke='black' />"
    )

    if h >= 22:
        svg.append(
            f"<text x='{x + 5}' y='{y + 14}' font-size='9' font-family='Arial'>{label}</text>"
        )

    if h >= 38:
        svg.append(
            f"<text x='{x + 5}' y='{y + 30}' font-size='8' font-family='Arial'>{size_label}</text>"
        )


def render_tall_column_markup(
    svg: list[str],
    *,
    module: dict,
    x: int,
    y: int,
    w: int,
    baseline_y: int,
    scale: float,
    kitchen_height_mm: int,
    plinth_height_mm: int,
    mezzanine_height_mm: int,
    wall_panel_top_mm: int,
) -> None:
    name = module.get("name")

    def y_from_floor(y_mm: int) -> int:
        return baseline_y - int(y_mm * scale)

    def section_rect(bottom_mm: int, height_mm: int) -> tuple[int, int]:
        top_mm = bottom_mm + height_mm
        return y_from_floor(top_mm), int(height_mm * scale)

    if name == "freestanding_fridge_in_carcass":
        body_width_mm = int(module.get("body_width_mm", module.get("width_mm", 600)))
        body_height_mm = int(module.get("body_height_mm", 2000))
        gap_mm = int(module.get("gap_mm", 20))
        side_width_mm = int(module.get("carcass_side_width_mm", 20))
        fridge_x = x + int((side_width_mm + gap_mm) * scale)
        fridge_w = int(body_width_mm * scale)
        side_w = max(1, int(side_width_mm * scale))
        top_panel_h = max(1, int(side_width_mm * scale))
        carcass_height_mm = min(
            kitchen_height_mm,
            body_height_mm + gap_mm + side_width_mm,
        )
        carcass_y, carcass_h = section_rect(0, carcass_height_mm)
        fridge_y, fridge_h = section_rect(0, min(body_height_mm, kitchen_height_mm))
        mezzanine_bottom_mm = max(0, kitchen_height_mm - mezzanine_height_mm)
        upper_bottom_mm = carcass_height_mm
        upper_height_mm = max(0, mezzanine_bottom_mm - upper_bottom_mm)

        svg.append(
            f"<rect x='{x}' y='{carcass_y}' width='{w}' height='{carcass_h}' fill='#f8fafc' stroke='black' />"
        )
        svg.append(
            f"<rect x='{x}' y='{carcass_y}' width='{side_w}' height='{carcass_h}' fill='#d1d5db' stroke='black' />"
        )
        svg.append(
            f"<rect x='{x + w - side_w}' y='{carcass_y}' width='{side_w}' height='{carcass_h}' fill='#d1d5db' stroke='black' />"
        )
        top_panel_y = baseline_y - int(carcass_height_mm * scale)
        svg.append(
            f"<rect x='{x}' y='{top_panel_y}' width='{w}' height='{top_panel_h}' fill='#d1d5db' stroke='black' />"
        )
        svg.append(
            f"<rect x='{fridge_x}' y='{fridge_y}' width='{fridge_w}' height='{fridge_h}' fill='#bfdbfe' stroke='black' />"
        )
        svg.append(
            f"<text x='{fridge_x + 5}' y='{fridge_y + 18}' font-size='9' font-family='Arial'>fridge</text>"
        )
        svg.append(
            f"<text x='{fridge_x + 5}' y='{fridge_y + 34}' font-size='8' font-family='Arial'>{body_width_mm} x {body_height_mm} mm</text>"
        )

        if upper_height_mm > 0:
            section_y, section_h = section_rect(upper_bottom_mm, upper_height_mm)
            append_column_section(
                svg,
                x=x,
                y=section_y,
                w=w,
                h=section_h,
                fill="#d1d5db",
                label="hinged",
                size_label=f"{upper_height_mm} mm",
            )

        if mezzanine_height_mm > 0:
            section_y, section_h = section_rect(mezzanine_bottom_mm, mezzanine_height_mm)
            append_column_section(
                svg,
                x=x,
                y=section_y,
                w=w,
                h=section_h,
                fill="#c7d2fe",
                label="mezzanine",
                size_label=f"{mezzanine_height_mm} mm",
            )

    if name == "built_in_fridge":
        freezer_height_mm = 723
        freezer_bottom_mm = plinth_height_mm
        freezer_top_mm = freezer_bottom_mm + freezer_height_mm
        mezzanine_bottom_mm = max(plinth_height_mm, kitchen_height_mm - mezzanine_height_mm)
        fridge_height_mm = max(0, mezzanine_bottom_mm - freezer_top_mm)

        sections = [
            (freezer_bottom_mm, freezer_height_mm, "#bfdbfe", "freezer", f"{freezer_height_mm} mm"),
            (freezer_top_mm, fridge_height_mm, "#dbeafe", "fridge", f"{fridge_height_mm} mm"),
            (mezzanine_bottom_mm, mezzanine_height_mm, "#c7d2fe", "mezzanine", f"{mezzanine_height_mm} mm"),
        ]

        for bottom_mm, height_mm, fill, label, size_label in sections:
            section_y, section_h = section_rect(bottom_mm, height_mm)
            append_column_section(
                svg,
                x=x,
                y=section_y,
                w=w,
                h=section_h,
                fill=fill,
                label=label,
                size_label=size_label,
            )

    if name == "oven_microwave_column":
        oven_height_mm = 584
        microwave_height_mm = int(module.get("microwave_height_mm", 400))
        mezzanine_bottom_mm = max(plinth_height_mm, kitchen_height_mm - mezzanine_height_mm)
        microwave_top_mm = min(wall_panel_top_mm, mezzanine_bottom_mm)
        microwave_bottom_mm = microwave_top_mm - microwave_height_mm
        oven_bottom_mm = microwave_bottom_mm - oven_height_mm
        drawer_bottom_mm = plinth_height_mm
        drawer_height_mm = max(0, oven_bottom_mm - drawer_bottom_mm)
        swing_bottom_mm = microwave_top_mm
        swing_height_mm = max(0, mezzanine_bottom_mm - swing_bottom_mm)

        sections = [
            (drawer_bottom_mm, drawer_height_mm, "#e5e7eb", "drawer", f"{drawer_height_mm} mm"),
            (oven_bottom_mm, oven_height_mm, "#fecaca", "oven", f"{oven_height_mm} mm"),
            (microwave_bottom_mm, microwave_height_mm, "#fde68a", "microwave", f"{microwave_height_mm} mm"),
            (swing_bottom_mm, swing_height_mm, "#d1d5db", "hinged", f"{swing_height_mm} mm"),
            (mezzanine_bottom_mm, mezzanine_height_mm, "#c7d2fe", "mezzanine", f"{mezzanine_height_mm} mm"),
        ]

        for bottom_mm, height_mm, fill, label, size_label in sections:
            section_y, section_h = section_rect(bottom_mm, height_mm)
            append_column_section(
                svg,
                x=x,
                y=section_y,
                w=w,
                h=section_h,
                fill=fill,
                label=label,
                size_label=size_label,
            )


def append_lower_profile_handles(
    svg: list[str],
    *,
    modules: list[dict],
    margin: int,
    scale: float,
    base_top_y: int,
) -> None:
    handle_height_px = max(1, int(30 * scale))
    sorted_modules = sorted(modules, key=lambda module: module.get("x_mm", 0))
    current_x = None
    current_width = 0

    def flush() -> None:
        if current_x is None or current_width <= 0:
            return

        x = margin + int(current_x * scale)
        w = int(current_width * scale)
        svg.append(
            f"<rect x='{x}' y='{base_top_y}' width='{w}' height='{handle_height_px}' fill='#4b5563' fill-opacity='0.85' stroke='#111827' />"
        )

    for module in sorted_modules:
        if module.get("type") != "base":
            flush()
            current_x = None
            current_width = 0
            continue

        module_x = module.get("x_mm", 0)
        module_width = module.get("width_mm", 0)

        if current_x is None:
            current_x = module_x
            current_width = module_width
            continue

        if module_x == current_x + current_width:
            current_width += module_width
        else:
            flush()
            current_x = module_x
            current_width = module_width

    flush()


def append_tall_profile_handles(
    svg: list[str],
    *,
    modules: list[dict],
    margin: int,
    scale: float,
    baseline_y: int,
    kitchen_height_mm: int,
    plinth_height_mm: int,
) -> None:
    tall_types = {"tall", "appliance_tall"}
    sorted_modules = sorted(modules, key=lambda module: module.get("x_mm", 0))
    handle_width_mm = 50
    handle_width_px = max(1, int(handle_width_mm * scale))
    handle_top_y = baseline_y - int(kitchen_height_mm * scale)
    handle_bottom_y = baseline_y - int(plinth_height_mm * scale)
    handle_height_px = handle_bottom_y - handle_top_y
    handle_boundaries = set()

    for index, module in enumerate(sorted_modules):
        if module.get("type") not in tall_types:
            continue

        module_x = module.get("x_mm", 0)
        module_end = module_x + module.get("width_mm", 0)
        previous_module = sorted_modules[index - 1] if index > 0 else None
        next_module = sorted_modules[index + 1] if index + 1 < len(sorted_modules) else None
        has_tall_neighbor = False

        if (
            previous_module
            and previous_module.get("type") in tall_types
            and previous_module.get("x_mm", 0) + previous_module.get("width_mm", 0) == module_x
        ):
            handle_boundaries.add(module_x)
            has_tall_neighbor = True

        if (
            next_module
            and next_module.get("type") in tall_types
            and module_end == next_module.get("x_mm", 0)
        ):
            handle_boundaries.add(module_end)
            has_tall_neighbor = True

        if has_tall_neighbor:
            continue

        if (
            previous_module
            and previous_module.get("x_mm", 0) + previous_module.get("width_mm", 0) == module_x
        ):
            handle_boundaries.add(module_x)
        elif next_module and module_end == next_module.get("x_mm", 0):
            handle_boundaries.add(module_end)

    for boundary_mm in sorted(handle_boundaries):
        x = margin + int((boundary_mm - handle_width_mm / 2) * scale)
        svg.append(
            f"<rect x='{x}' y='{handle_top_y}' width='{handle_width_px}' height='{handle_height_px}' fill='#374151' fill-opacity='0.88' stroke='#111827' />"
        )


def _corner_side_layout(layout: dict, side_key: str) -> dict:
    side = layout.get(side_key, {})
    side_width_mm = side.get("wall_length_mm", layout.get("wall_length_mm", 3000))
    modules = side.get("modules", [])
    wall_modules = side.get("wall_modules", [])
    front_objects = side.get("front_objects", [])
    plinth_modules = side.get("plinth_modules", [])
    countertop_modules = side.get("countertop_modules", [])
    wall_panel_modules = side.get("wall_panel_modules", [])

    side_layout = {
        **layout,
        "shape": "straight",
        "wall_length_mm": side_width_mm,
        "used_width_mm": max(
            [
                module.get("x_mm", 0) + module.get("width_mm", 0)
                for module in modules
            ]
            or [0]
        ),
        "modules": modules,
        "wall_modules": wall_modules,
        "front_objects": front_objects,
        "plinth_modules": plinth_modules,
        "countertop_modules": countertop_modules,
        "wall_panel_modules": wall_panel_modules,
    }

    return side_layout


def render_front_view(layout: dict) -> str:
    if layout.get("shape") == "corner":
        return render_front_view(_corner_side_layout(layout, "side_1"))

    scale = 0.25
    margin = 40

    base_height_mm = layout.get("base_module_height_mm", 720)
    plinth_height_mm = layout.get("plinth_height_mm", 100)
    kitchen_height_mm = layout.get("kitchen_height_mm", 2700)
    wall_panel_height_mm = 600

    display_length_mm = max(
        layout.get("wall_length_mm", 3000),
        layout.get("used_width_mm", 0),
    )

    width_px = int(display_length_mm * scale) + margin * 2
    header_height = 72
    baseline_y = header_height + int(kitchen_height_mm * scale)
    height_px = baseline_y + 70

    svg = []
    svg.append(f"<svg xmlns='http://www.w3.org/2000/svg' width='{width_px}' height='{height_px}'>")
    svg.append("<rect width='100%' height='100%' fill='white' />")
    svg.append(f"<text x='{margin}' y='24' font-size='16' font-family='Arial'>Front View</text>")
    svg.append(
        f"<text x='{margin}' y='44' font-size='12' font-family='Arial'>Countertop height: {layout.get('countertop_height_mm', 0)} mm | Base modules: {layout.get('base_module_height_mm', 0)} mm | Plinth: {layout.get('plinth_height_mm', 0)} mm</text>"
    )

    base_height_px = int(base_height_mm * scale)
    plinth_height_px = int(plinth_height_mm * scale)
    base_bottom_y = baseline_y - plinth_height_px
    base_top_y = base_bottom_y - base_height_px

    global_countertop_thickness_px = int(
        layout.get("countertop_thickness_mm", 38) * scale
    )
    mezzanine_height_mm = get_mezzanine_height_mm(layout)
    wall_panel_top_mm = (
        plinth_height_mm
        + base_height_mm
        + layout.get("countertop_thickness_mm", 38)
        + wall_panel_height_mm
    )

    # Стеновая панель.
    # Она отображается только над нижними base-модулями,
    # не строится за пенальными группами
    # и физически находится за столешницей и за соло-микроволновкой.
    for panel in layout.get("wall_panel_modules", []):
        x = margin + int(panel["x_mm"] * scale)
        w = int(panel["width_mm"] * scale)
        h = int(wall_panel_height_mm * scale)

        countertop_thickness_px = int(
            panel.get(
                "countertop_thickness_mm",
                layout.get("countertop_thickness_mm", 38),
            )
            * scale
        )

        y = base_top_y - countertop_thickness_px - h

        svg.append(
            f"<rect x='{x}' y='{y}' width='{w}' height='{h}' fill='#fef3c7' stroke='#d97706' stroke-dasharray='4 3' />"
        )
        svg.append(
            f"<text x='{x + 6}' y='{y + 22}' font-size='11' font-family='Arial'>wall panel</text>"
        )
        svg.append(
            f"<text x='{x + 6}' y='{y + 40}' font-size='10' font-family='Arial'>{panel['width_mm']} x {panel['height_mm']} mm</text>"
        )

    # Верхние модули и вытяжка
    for module in layout.get("wall_modules", []):
        x = margin + int(module["x_mm"] * scale)
        w = int(module["width_mm"] * scale)
        h = int(module.get("height_mm", 400) * scale)

        y_mm = module.get("y_mm", 1450)
        y = baseline_y - int((y_mm + module.get("height_mm", 400)) * scale)

        if "hood" in module["name"]:
            fill = "#fca5a5"
        elif "microwave" in module["name"]:
            fill = "#fde68a"
        else:
            fill = "#bfdbfe"

        svg.append(
            f"<rect x='{x}' y='{y}' width='{w}' height='{h}' fill='{fill}' stroke='black' />"
        )
        door_x = x
        for door_width_mm in module.get("facade_door_widths_mm", [])[:-1]:
            door_x += int(door_width_mm * scale)
            svg.append(
                f"<line x1='{door_x}' y1='{y}' x2='{door_x}' y2='{y + h}' stroke='black' stroke-width='1' />"
            )
        svg.append(
            f"<text x='{x + 6}' y='{y + 24}' font-size='10' font-family='Arial'>{module['width_mm']} mm</text>"
        )

    # Нижние и высокие модули
    for module in layout.get("modules", []):
        x = margin + int(module["x_mm"] * scale)
        w = int(module["width_mm"] * scale)

        if module["type"] == "profile_handle":
            h = int(module.get("height_mm", kitchen_height_mm - plinth_height_mm) * scale)
            y = baseline_y - plinth_height_px - h
            fill = "#374151"
        elif module["type"] in {"tall", "appliance_tall"}:
            h = int(module.get("height_mm", kitchen_height_mm) * scale)
            y = baseline_y - h
            fill = "#cbd5e1"
        elif module["type"] == "freestanding_solo":
            h = int(module.get("height_mm", 2000) * scale)
            y = baseline_y - h
            fill = "#fecaca"
        elif module.get("countertop_role") == "free_worktop":
            h = base_height_px
            y = base_top_y
            fill = "#dcfce7"
        elif module.get("countertop_role") == "blocked":
            h = base_height_px
            y = base_top_y
            fill = "#fee2e2"
        else:
            h = base_height_px
            y = base_top_y
            fill = "#d1d5db"

        svg.append(
            f"<rect x='{x}' y='{y}' width='{w}' height='{h}' fill='{fill}' stroke='black' />"
        )

        if module["type"] in {"tall", "appliance_tall"}:
            render_tall_column_markup(
                svg,
                module=module,
                x=x,
                y=y,
                w=w,
                baseline_y=baseline_y,
                scale=scale,
                kitchen_height_mm=kitchen_height_mm,
                plinth_height_mm=plinth_height_mm,
                mezzanine_height_mm=mezzanine_height_mm,
                wall_panel_top_mm=wall_panel_top_mm,
            )

        if module["type"] == "profile_handle":
            continue

        if module.get("name") not in {
            "oven_microwave_column",
            "built_in_fridge",
            "freestanding_fridge_in_carcass",
        }:
            svg.append(
                f"<text x='{x + 6}' y='{y + 22}' font-size='11' font-family='Arial'>{module['name']}</text>"
            )
            svg.append(
                f"<text x='{x + 6}' y='{y + 40}' font-size='10' font-family='Arial'>{module['width_mm']} mm</text>"
            )

    # Столешница.
    # Показывается только на front view.
    # Идёт над нижними модулями по тем же участкам, что и стеновая панель.
    append_lower_profile_handles(
        svg,
        modules=layout.get("modules", []),
        margin=margin,
        scale=scale,
        base_top_y=base_top_y,
    )

    for countertop in layout.get("countertop_modules", []):
        x = margin + int(countertop["x_mm"] * scale)
        w = int(countertop["width_mm"] * scale)
        h = int(
            countertop.get(
                "thickness_mm",
                countertop.get("height_mm", 38),
            )
            * scale
        )

        y = base_top_y - h

        material_label = countertop.get("material_label", "countertop")
        thickness_mm = countertop.get("thickness_mm", countertop.get("height_mm", 38))

        svg.append(
            f"<rect x='{x}' y='{y}' width='{w}' height='{h}' fill='#a8a29e' stroke='black' />"
        )
        svg.append(
            f"<text x='{x + 6}' y='{y - 4}' font-size='10' font-family='Arial'>{material_label}, {thickness_mm} mm</text>"
        )

    # Цоколь.
    # Идёт по низу вдоль base-модулей и пенальных модулей.
    # Не идёт под отдельно стоящим холодильником.
    for plinth in layout.get("plinth_modules", []):
        x = margin + int(plinth["x_mm"] * scale)
        w = int(plinth["width_mm"] * scale)
        h = plinth_height_px

        y = baseline_y - h

        svg.append(
            f"<rect x='{x}' y='{y}' width='{w}' height='{h}' fill='#9ca3af' stroke='black' />"
        )
        svg.append(
            f"<text x='{x + 6}' y='{y + 17}' font-size='10' font-family='Arial'>plinth {plinth_height_mm} mm</text>"
        )

    # Объекты только для фронтального вида: например, соло микроволновка.
    # Она рисуется после стеновой панели и столешницы, поэтому визуально находится перед ними.
    for obj in layout.get("front_objects", []):
        x = margin + int(obj["x_mm"] * scale)
        w = int(obj["width_mm"] * scale)
        h = int(obj.get("height_mm", 250) * scale)

        y = base_top_y - global_countertop_thickness_px - h

        svg.append(
            f"<rect x='{x}' y='{y}' width='{w}' height='{h}' fill='#fde68a' stroke='black' />"
        )
        if obj["name"] == "hob":
            continue

        svg.append(
            f"<text x='{x + 6}' y='{y + 22}' font-size='11' font-family='Arial'>{obj['name']}</text>"
        )
        svg.append(
            f"<text x='{x + 6}' y='{y + 40}' font-size='10' font-family='Arial'>{obj['width_mm']} mm</text>"
        )

    svg.append(
        f"<line x1='{margin}' y1='{baseline_y}' x2='{width_px - margin}' y2='{baseline_y}' stroke='black' />"
    )

    svg.append("</svg>")
    return "".join(svg)


def render_side_view(layout: dict) -> str:
    if layout.get("shape") != "corner":
        return ""

    return render_front_view(_corner_side_layout(layout, "side_2")).replace(
        "Front View",
        "Side View",
        1,
    )
