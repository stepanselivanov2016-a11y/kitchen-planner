"use client";

import { FormEvent, useMemo, useState } from "react";

type CountertopMaterial =
  | "chipboard_plastic"
  | "quartz_agglomerate"
  | "natural_stone"
  | "acrylic_stone"
  | "compact_plate";

type CustomerHeightMode =
  | "height_170_or_below"
  | "exact"
  | "height_196_or_above";

type SizeAdjustment = {
  field: "sink.width_mm" | "dishwasher.width_mm" | string;
  label: string;
  from_mm?: number;
  to_mm?: number;
  from_value?: string;
  to_value?: string;
  reason: string;
};

type KitchenOptions = {
  room: {
    layout_shape: "straight" | "corner";
    wall_length_mm: number;
    side_1_width_mm: number;
    side_2_width_mm: number;
    kitchen_height_mm: number;
    wall_cabinets_enabled: boolean;
    mezzanine_enabled: boolean;
    entry_side: "left" | "right";
    customer_height_mode: CustomerHeightMode;
    customer_height_cm: number;
    countertop_material: CountertopMaterial;
    countertop_thickness_mm: number;
  };
  required: {
    refrigerator: {
      mode: "built_in" | "freestanding";
      freestanding_installation: "in_cabinet" | "solo";
      width_mm: number;
      depth_mm: number;
      height_mm: number;
      gap_mm: number;
    };
    oven: {
      placement: "under_counter" | "column";
    };
    sink: {
      width_mm: number;
    };
    hood: {
      type: "built_in" | "solo";
      width_mm: number;
    };
    microwave: {
      type: "built_in" | "upper_built_in" | "solo";
      width_mm: number;
      height_mm: number;
    };
    hob: {
      cabinet_width_mm: number;
    };
  };
  optional: {
    dishwasher: {
      enabled: boolean;
      width_mm: number;
    };
    undercounter_fridge: {
      enabled: boolean;
    };
    wine_cabinet: {
      enabled: boolean;
    };
  };
  locked: Record<string, boolean>;
};

type Result = {
  normalized_spec: Record<string, unknown>;
  module_options: KitchenOptions;
  generated_layout: {
    sink_edge?: "left" | "right";
    fridge_edge?: "left" | "right";
    customer_height_mode?: CustomerHeightMode;
    customer_height_cm?: number;
    countertop_height_mm?: number;
    kitchen_height_mm?: number;
    wall_cabinets_enabled?: boolean;
    mezzanine_enabled?: boolean;
    base_module_height_mm?: number;
    plinth_height_mm?: number;
    countertop_material?: CountertopMaterial;
    countertop_material_label?: string;
    countertop_thickness_mm?: number;
    size_adjustments?: SizeAdjustment[];
    modules: Array<Record<string, unknown>>;
    wall_modules: Array<Record<string, unknown>>;
    front_objects: Array<Record<string, unknown>>;
    warnings: string[];
  };
  top_view_svg: string;
  front_view_svg: string;
  side_view_svg?: string;
};

const hoodPresetWidths = [600, 900, 1200, 1800];
const AUTO_SELECT_VALUE = "__auto__";

const countertopMaterialLabels: Record<CountertopMaterial, string> = {
  chipboard_plastic: "ДСП пластик",
  quartz_agglomerate: "Кварцевый агломерат",
  natural_stone: "Натуральный камень",
  acrylic_stone: "Искусственный камень (акрил)",
  compact_plate: "Компакт-плита",
};

const countertopThicknessOptions: Record<CountertopMaterial, number[]> = {
  chipboard_plastic: [28, 38],
  quartz_agglomerate: [20, 40, 60],
  natural_stone: [20, 50],
  acrylic_stone: [20, 30, 40, 51],
  compact_plate: [12],
};

const countertopCustomThicknessDefaults: Partial<
  Record<CountertopMaterial, number>
> = {
  quartz_agglomerate: 30,
  acrylic_stone: 35,
};

function materialAllowsCustomThickness(material: CountertopMaterial) {
  return material === "quartz_agglomerate" || material === "acrylic_stone";
}

const defaultOptions: KitchenOptions = {
  room: {
    layout_shape: "straight",
    wall_length_mm: 3000,
    side_1_width_mm: 3000,
    side_2_width_mm: 2400,
    kitchen_height_mm: 2700,
    wall_cabinets_enabled: true,
    mezzanine_enabled: true,
    entry_side: "left",
    customer_height_mode: "exact",
    customer_height_cm: 175,
    countertop_material: "chipboard_plastic",
    countertop_thickness_mm: 38,
  },
  required: {
    refrigerator: {
      mode: "built_in",
      freestanding_installation: "solo",
      width_mm: 600,
      depth_mm: 650,
      height_mm: 2000,
      gap_mm: 20,
    },
    oven: {
      placement: "under_counter",
    },
    sink: {
      width_mm: 600,
    },
    hood: {
      type: "built_in",
      width_mm: 600,
    },
    microwave: {
      type: "upper_built_in",
      width_mm: 600,
      height_mm: 400,
    },
    hob: {
      cabinet_width_mm: 600,
    },
  },
  optional: {
    dishwasher: {
      enabled: false,
      width_mm: 600,
    },
    undercounter_fridge: {
      enabled: false,
    },
    wine_cabinet: {
      enabled: false,
    },
  },
  locked: {},
};

function renderAdjustmentValue(adjustment: SizeAdjustment) {
  if (
    typeof adjustment.from_mm === "number" &&
    typeof adjustment.to_mm === "number"
  ) {
    return (
      <>
        {adjustment.from_mm} мм →{" "}
        <span className="font-semibold">{adjustment.to_mm} мм</span>
      </>
    );
  }

  return (
    <>
      {adjustment.from_value} →{" "}
      <span className="font-semibold">{adjustment.to_value}</span>
    </>
  );
}

export default function HomePage() {
  const [options, setOptions] = useState<KitchenOptions>(defaultOptions);
  const [notes, setNotes] = useState("");
  const [result, setResult] = useState<Result | null>(null);
  const [loading, setLoading] = useState(false);

  function updateRoom(patch: Partial<KitchenOptions["room"]>) {
    setOptions((current) => ({
      ...current,
      room: {
        ...current.room,
        ...patch,
      },
    }));
  }

  function updateRequired<K extends keyof KitchenOptions["required"]>(
    key: K,
    patch: Partial<KitchenOptions["required"][K]>
  ) {
    setOptions((current) => ({
      ...current,
      required: {
        ...current.required,
        [key]: {
          ...current.required[key],
          ...patch,
        },
      },
    }));
  }

  function updateOptional<K extends keyof KitchenOptions["optional"]>(
    key: K,
    patch: Partial<KitchenOptions["optional"][K]>
  ) {
    setOptions((current) => ({
      ...current,
      optional: {
        ...current.optional,
        [key]: {
          ...current.optional[key],
          ...patch,
        },
      },
    }));
  }

  function updateLocked(field: string, value: boolean) {
    setOptions((current) => ({
      ...current,
      locked: {
        ...current.locked,
        [field]: value,
      },
    }));
  }

  function unlockField(field: string) {
    updateLocked(field, false);
  }

  function updateRoomAndLock(
    field: string,
    patch: Partial<KitchenOptions["room"]>
  ) {
    setOptions((current) => ({
      ...current,
      room: {
        ...current.room,
        ...patch,
      },
      locked: {
        ...current.locked,
        [field]: true,
      },
    }));
  }

  function updateRequiredAndLock<K extends keyof KitchenOptions["required"]>(
    field: string,
    key: K,
    patch: Partial<KitchenOptions["required"][K]>
  ) {
    setOptions((current) => ({
      ...current,
      required: {
        ...current.required,
        [key]: {
          ...current.required[key],
          ...patch,
        },
      },
      locked: {
        ...current.locked,
        [field]: true,
      },
    }));
  }

  function updateOptionalAndLock<K extends keyof KitchenOptions["optional"]>(
    field: string,
    key: K,
    patch: Partial<KitchenOptions["optional"][K]>
  ) {
    setOptions((current) => ({
      ...current,
      optional: {
        ...current.optional,
        [key]: {
          ...current.optional[key],
          ...patch,
        },
      },
      locked: {
        ...current.locked,
        [field]: true,
      },
    }));
  }

  function isLocked(field: string) {
    return Boolean(options.locked[field]);
  }

  function applySizeAdjustmentsToForm(data: Result) {
    const adjustments = data.generated_layout.size_adjustments ?? [];

    if (adjustments.length === 0) {
      return;
    }

    setOptions((current) => {
      let nextSinkWidth = current.required.sink.width_mm;
      let nextWallLength = current.room.wall_length_mm;
      let nextSide1Width = current.room.side_1_width_mm;
      let nextSide2Width = current.room.side_2_width_mm;
      let nextHobWidth = current.required.hob.cabinet_width_mm;
      let nextRefrigeratorMode = current.required.refrigerator.mode;
      let nextFreestandingInstallation =
        current.required.refrigerator.freestanding_installation;
      let nextHoodType = current.required.hood.type;
      let nextHoodWidth = current.required.hood.width_mm;
      let nextWallCabinetsEnabled = current.room.wall_cabinets_enabled;
      let nextMezzanineEnabled = current.room.mezzanine_enabled;
      let nextKitchenHeight = current.room.kitchen_height_mm;
      let nextOvenPlacement = current.required.oven.placement;
      let nextMicrowaveType = current.required.microwave.type;
      let nextMicrowaveWidth = current.required.microwave.width_mm;
      let nextMicrowaveHeight = current.required.microwave.height_mm;
      let nextDishwasherWidth = current.optional.dishwasher.width_mm;
      let nextDishwasherEnabled = current.optional.dishwasher.enabled;

      for (const adjustment of adjustments) {
        if (current.locked[adjustment.field]) {
          continue;
        }

        if (
          adjustment.field === "room.wall_cabinets_enabled" &&
          typeof adjustment.to_value === "string"
        ) {
          nextWallCabinetsEnabled = adjustment.to_value.includes("включ");
        }

        if (
          adjustment.field === "room.mezzanine_enabled" &&
          typeof adjustment.to_value === "string"
        ) {
          nextMezzanineEnabled = adjustment.to_value.includes("\u0432\u043a\u043b\u044e\u0447");
        }

        if (
          adjustment.field === "room.wall_length_mm" &&
          typeof adjustment.to_mm === "number"
        ) {
          nextWallLength = adjustment.to_mm;
          nextSide1Width = adjustment.to_mm;
        }

        if (
          adjustment.field === "room.kitchen_height_mm" &&
          typeof adjustment.to_mm === "number"
        ) {
          nextKitchenHeight = adjustment.to_mm;
        }

        if (
          adjustment.field === "refrigerator.mode" &&
          typeof adjustment.to_value === "string"
        ) {
          nextRefrigeratorMode = adjustment.to_value.includes("встра")
            ? "built_in"
            : "freestanding";
        }

        if (
          adjustment.field === "refrigerator.freestanding_installation" &&
          typeof adjustment.to_value === "string"
        ) {
          nextFreestandingInstallation = adjustment.to_value.includes("корпус")
            ? "in_cabinet"
            : "solo";
        }

        if (
          adjustment.field === "hood.type" &&
          typeof adjustment.to_value === "string"
        ) {
          nextHoodType = adjustment.to_value.includes("встро")
            ? "built_in"
            : "solo";
        }

        if (
          adjustment.field === "hood.width_mm" &&
          typeof adjustment.to_mm === "number"
        ) {
          nextHoodWidth = adjustment.to_mm;
        }

        if (
          adjustment.field === "sink.width_mm" &&
          typeof adjustment.to_mm === "number"
        ) {
          nextSinkWidth = adjustment.to_mm;
        }

        if (
          adjustment.field === "dishwasher.width_mm" &&
          typeof adjustment.to_mm === "number"
        ) {
          nextDishwasherWidth = adjustment.to_mm;
          nextDishwasherEnabled = true;
        }

        if (
          adjustment.field === "hob.cabinet_width_mm" &&
          typeof adjustment.to_mm === "number"
        ) {
          nextHobWidth = adjustment.to_mm;
        }

        if (
          adjustment.field === "oven.placement" &&
          typeof adjustment.to_value === "string"
        ) {
          nextOvenPlacement = adjustment.to_value.includes("колон")
            ? "column"
            : "under_counter";
        }

        if (
          adjustment.field === "microwave.type" &&
          typeof adjustment.to_value === "string"
        ) {
          nextMicrowaveType = adjustment.to_value.includes("\u0432\u043a\u043b\u044e\u0447")
            ? "upper_built_in"
            : adjustment.to_value.includes("\u0432\u043a\u043b\u044e\u0447")
              ? "built_in"
              : "solo";

          if (
            nextMicrowaveType === "built_in" ||
            nextMicrowaveType === "upper_built_in"
          ) {
            nextMicrowaveWidth = 600;
            nextMicrowaveHeight = 400;
          } else {
            nextMicrowaveWidth = 450;
            nextMicrowaveHeight = 250;
          }
        }

        if (
          adjustment.field === "microwave.width_mm" &&
          typeof adjustment.to_mm === "number"
        ) {
          nextMicrowaveWidth = adjustment.to_mm;
        }

        if (
          adjustment.field === "microwave.height_mm" &&
          typeof adjustment.to_mm === "number"
        ) {
          nextMicrowaveHeight = adjustment.to_mm;
        }
      }

      return {
        ...current,
        room: {
          ...current.room,
          wall_length_mm: nextWallLength,
          side_1_width_mm: nextSide1Width,
          side_2_width_mm: nextSide2Width,
          wall_cabinets_enabled: nextWallCabinetsEnabled,
          mezzanine_enabled: nextMezzanineEnabled,
          kitchen_height_mm: nextKitchenHeight,
        },
        required: {
          ...current.required,
          sink: {
            ...current.required.sink,
            width_mm: nextSinkWidth,
          },
          refrigerator: {
            ...current.required.refrigerator,
            mode: nextRefrigeratorMode,
            freestanding_installation: nextFreestandingInstallation,
          },
          hood: {
            ...current.required.hood,
            type: nextHoodType,
            width_mm: nextHoodWidth,
          },
          oven: {
            ...current.required.oven,
            placement: nextOvenPlacement,
          },
          microwave: {
            ...current.required.microwave,
            type: nextMicrowaveType,
            width_mm: nextMicrowaveWidth,
            height_mm: nextMicrowaveHeight,
          },
          hob: {
            ...current.required.hob,
            cabinet_width_mm: nextHobWidth,
          },
        },
        optional: {
          ...current.optional,
          dishwasher: {
            ...current.optional.dishwasher,
            enabled: nextDishwasherEnabled,
            width_mm: nextDishwasherWidth,
          },
        },
      };
    });
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);

    const res = await fetch("/api/plan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        prompt:
          options.room.layout_shape === "corner"
            ? `Угловая кухня ${options.room.side_1_width_mm} x ${options.room.side_2_width_mm} мм. ${notes}`
            : `Кухня ${options.room.wall_length_mm} мм. ${notes}`,
        module_options: options,
      }),
    });

    const data: Result = await res.json();

    setResult(data);
    setLoading(false);
  }

  const hoodSelectValue = hoodPresetWidths.includes(
    options.required.hood.width_mm
  )
    ? String(options.required.hood.width_mm)
    : "custom";

  const currentCountertopThicknessOptions = useMemo(
    () => countertopThicknessOptions[options.room.countertop_material],
    [options.room.countertop_material]
  );

  const countertopThicknessSelectValue = currentCountertopThicknessOptions.includes(
    options.room.countertop_thickness_mm
  )
    ? String(options.room.countertop_thickness_mm)
    : "custom";

  return (
    <main className="max-w-6xl mx-auto p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Kitchen Planner MVP</h1>
        <p className="text-gray-600 mt-2">
          Выбери обязательные и необязательные элементы кухни.
        </p>
      </div>

      <form onSubmit={onSubmit} className="space-y-8">
        <section className="border rounded-xl p-5 space-y-4">
          <h2 className="text-xl font-semibold">Вариант кухни</h2>

          <label className="block">
            <span className="block mb-1">Форма</span>
            <select
              className="border rounded p-2 w-full"
              value={options.room.layout_shape}
              onChange={(e) =>
                updateRoom({
                  layout_shape: e.target.value as "straight" | "corner",
                })
              }
            >
              <option value="straight">Прямая</option>
              <option value="corner">Угловая</option>
            </select>
          </label>

          {options.room.layout_shape === "corner" && (
            <div className="grid md:grid-cols-2 gap-4">
              <label className="block">
                <span className="block mb-1">Ширина стороны 1, мм</span>
                <input
                  type="number"
                  className="border rounded p-2 w-full"
                  value={options.room.side_1_width_mm}
                  onChange={(e) =>
                    updateRoom({
                      side_1_width_mm: Number(e.target.value),
                      wall_length_mm: Number(e.target.value),
                    })
                  }
                />
              </label>

              <label className="block">
                <span className="block mb-1">Ширина стороны 2, мм</span>
                <input
                  type="number"
                  className="border rounded p-2 w-full"
                  value={options.room.side_2_width_mm}
                  onChange={(e) =>
                    updateRoom({ side_2_width_mm: Number(e.target.value) })
                  }
                />
              </label>
            </div>
          )}

          {options.room.layout_shape === "straight" && (
            <label className="block">
              <span className="block mb-1">Ширина кухни, мм</span>
              <input
                type="number"
                className="border rounded p-2 w-full"
                value={options.room.wall_length_mm}
                onChange={(e) =>
                  updateRoom({
                    wall_length_mm: Number(e.target.value),
                    side_1_width_mm: Number(e.target.value),
                  })
                }
              />
            </label>
          )}

          <label className="block">
            <span className="block mb-1">Высота кухни, мм</span>
            <input
              type="number"
              className="border rounded p-2 w-full"
              value={options.room.kitchen_height_mm}
              onChange={(e) =>
                updateRoom({ kitchen_height_mm: Number(e.target.value) })
              }
            />
          </label>
        </section>
        <section className="border rounded-xl p-5 space-y-4">
          <h2 className="text-xl font-semibold">Общие параметры</h2>

          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={options.room.wall_cabinets_enabled}
              onChange={(e) =>
                updateRoom({ wall_cabinets_enabled: e.target.checked })
              }
            />
            <span>Навесные шкафы</span>
          </label>
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={options.room.mezzanine_enabled}
              disabled={!options.room.wall_cabinets_enabled}
              onChange={(e) =>
                updateRoomAndLock("room.mezzanine_enabled", {
                  mezzanine_enabled: e.target.checked,
                })
              }
            />
            <span>Антресольные шкафы</span>
          </label>

          <label className="block">
            <span className="block mb-1">
              С какой стороны вывод воды?
            </span>

            <select
              className="border rounded p-2 w-full"
              value={options.room.entry_side}
              onChange={(e) =>
                updateRoom({
                  entry_side: e.target.value as "left" | "right",
                })
              }
            >
              <option value="left">Слева</option>
              <option value="right">Справа</option>
            </select>
          </label>

          <div className="border rounded-xl p-4 space-y-3">
            <h3 className="font-semibold">Рост заказчика</h3>

            <label className="block">
              <span className="block mb-1">Как указать рост?</span>
              <select
                className="border rounded p-2 w-full"
                value={options.room.customer_height_mode}
                onChange={(e) => {
                  const nextMode = e.target.value as CustomerHeightMode;

                  if (nextMode === "height_170_or_below") {
                    updateRoom({
                      customer_height_mode: nextMode,
                      customer_height_cm: 170,
                    });
                    return;
                  }

                  if (nextMode === "height_196_or_above") {
                    updateRoom({
                      customer_height_mode: nextMode,
                      customer_height_cm: 196,
                    });
                    return;
                  }

                  updateRoom({
                    customer_height_mode: nextMode,
                    customer_height_cm:
                      options.room.customer_height_cm < 150 ||
                      options.room.customer_height_cm > 196
                        ? 175
                        : options.room.customer_height_cm,
                  });
                }}
              >
                <option value="height_170_or_below">170 см и ниже</option>
                <option value="exact">Указать точный рост</option>
                <option value="height_196_or_above">196 см и выше</option>
              </select>
            </label>

            {options.room.customer_height_mode === "exact" && (
              <label className="block">
                <span className="block mb-1">Рост, см</span>
                <input
                  type="number"
                  min={150}
                  max={196}
                  className="border rounded p-2 w-full"
                  value={options.room.customer_height_cm}
                  onChange={(e) =>
                    updateRoom({
                      customer_height_cm: Number(e.target.value),
                    })
                  }
                />
                <span className="text-sm text-gray-500">
                  Можно указать любое значение от 150 до 196 см.
                </span>
              </label>
            )}
          </div>

          <div className="border rounded-xl p-4 space-y-3">
            <h3 className="font-semibold">Столешница</h3>

            <label className="block">
              <span className="block mb-1">Материал столешницы</span>
              <select
                className="border rounded p-2 w-full"
                value={options.room.countertop_material}
                onChange={(e) => {
                  const nextMaterial = e.target.value as CountertopMaterial;
                  const nextThicknessOptions =
                    countertopThicknessOptions[nextMaterial];
                  const currentThickness = options.room.countertop_thickness_mm;

                  let nextThickness = currentThickness;

                  if (!nextThicknessOptions.includes(currentThickness)) {
                    if (materialAllowsCustomThickness(nextMaterial)) {
                      nextThickness =
                        countertopCustomThicknessDefaults[nextMaterial] ??
                        nextThicknessOptions[0];
                    } else {
                      nextThickness = nextThicknessOptions[0];
                    }
                  }

                  updateRoom({
                    countertop_material: nextMaterial,
                    countertop_thickness_mm: nextThickness,
                  });
                }}
              >
                {(
                  Object.keys(countertopMaterialLabels) as CountertopMaterial[]
                ).map((material) => (
                  <option key={material} value={material}>
                    {countertopMaterialLabels[material]}
                  </option>
                ))}
              </select>
            </label>

            <label className="block">
              <span className="block mb-1">Толщина столешницы, мм</span>
              <select
                className="border rounded p-2 w-full"
                value={countertopThicknessSelectValue}
                onChange={(e) => {
                  const value = e.target.value;
                  const material = options.room.countertop_material;

                  if (value === "custom") {
                    const customDefault =
                      countertopCustomThicknessDefaults[material] ??
                      options.room.countertop_thickness_mm;

                    updateRoom({
                      countertop_thickness_mm: customDefault,
                    });
                    return;
                  }

                  updateRoom({
                    countertop_thickness_mm: Number(value),
                  });
                }}
              >
                {currentCountertopThicknessOptions.map((thickness) => (
                  <option key={thickness} value={thickness}>
                    {thickness} мм
                  </option>
                ))}

                {materialAllowsCustomThickness(
                  options.room.countertop_material
                ) && <option value="custom">Произвольный размер</option>}
              </select>
            </label>

            {materialAllowsCustomThickness(options.room.countertop_material) &&
              !currentCountertopThicknessOptions.includes(
                options.room.countertop_thickness_mm
              ) && (
                <label className="block">
                  <span className="block mb-1">Свой размер, мм</span>
                  <input
                    type="number"
                    className="border rounded p-2 w-full"
                    value={options.room.countertop_thickness_mm}
                    onChange={(e) =>
                      updateRoom({
                        countertop_thickness_mm: Number(e.target.value),
                      })
                    }
                  />
                </label>
              )}
          </div>

          <label className="block">
            <span className="block mb-1">Дополнительные пожелания текстом</span>
            <textarea
              className="border rounded p-2 w-full min-h-24"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Например: холодильник справа, мойка ближе к центру..."
            />
          </label>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-semibold">Обязательные элементы</h2>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="border rounded-xl p-5 space-y-3">
              <h3 className="font-semibold">Холодильник</h3>

              <label className="block">
                <span className="block mb-1">Тип</span>
                <select
                  className="border rounded p-2 w-full"
                  value={
                    isLocked("refrigerator.mode")
                      ? options.required.refrigerator.mode
                      : AUTO_SELECT_VALUE
                  }
                  onChange={(e) => {
                    if (e.target.value === AUTO_SELECT_VALUE) {
                      unlockField("refrigerator.mode");
                      return;
                    }

                    updateRequiredAndLock(
                      "refrigerator.mode",
                      "refrigerator",
                      {
                        mode: e.target.value as "built_in" | "freestanding",
                      }
                    );
                  }}
                >
                  <option value={AUTO_SELECT_VALUE}>Авто</option>
                  <option value="built_in">Встраиваемый</option>
                  <option value="freestanding">Отдельно стоящий</option>
                </select>
              </label>


              {options.required.refrigerator.mode === "freestanding" && (
                <>
                  <label className="block">
                    <span className="block mb-1">Как ставим</span>
                    <select
                      className="border rounded p-2 w-full"
                      value={
                        options.required.refrigerator.freestanding_installation
                      }
                      onChange={(e) =>
                        updateRequiredAndLock(
                          "refrigerator.freestanding_installation",
                          "refrigerator",
                          {
                          freestanding_installation: e.target.value as
                            | "in_cabinet"
                            | "solo",
                          }
                        )
                      }
                    >
                      <option value="in_cabinet">
                        Внутри мебельного каркаса
                      </option>
                      <option value="solo">Соло рядом с кухней</option>
                    </select>
                  </label>

                  <div className="grid grid-cols-2 gap-3">
                    <label>
                      <span className="block mb-1">Ширина, мм</span>
                      <input
                        type="number"
                        className="border rounded p-2 w-full"
                        value={options.required.refrigerator.width_mm}
                        onChange={(e) =>
                          updateRequired("refrigerator", {
                            width_mm: Number(e.target.value),
                          })
                        }
                      />
                    </label>

                    <label>
                      <span className="block mb-1">Глубина, мм</span>
                      <input
                        type="number"
                        className="border rounded p-2 w-full"
                        value={options.required.refrigerator.depth_mm}
                        onChange={(e) =>
                          updateRequired("refrigerator", {
                            depth_mm: Number(e.target.value),
                          })
                        }
                      />
                    </label>

                    <label>
                      <span className="block mb-1">Высота, мм</span>
                      <input
                        type="number"
                        className="border rounded p-2 w-full"
                        value={options.required.refrigerator.height_mm}
                        onChange={(e) =>
                          updateRequired("refrigerator", {
                            height_mm: Number(e.target.value),
                          })
                        }
                      />
                    </label>

                    <label>
                      <span className="block mb-1">Зазор, мм</span>
                      <input
                        type="number"
                        className="border rounded p-2 w-full"
                        value={options.required.refrigerator.gap_mm}
                        onChange={(e) =>
                          updateRequired("refrigerator", {
                            gap_mm: Number(e.target.value),
                          })
                        }
                      />
                    </label>
                  </div>
                </>
              )}
            </div>

            <div className="border rounded-xl p-5 space-y-3">
              <h3 className="font-semibold">Духовка</h3>

              <label className="block">
                <span className="block mb-1">Расположение</span>
                <select
                  className="border rounded p-2 w-full"
                  value={
                    isLocked("oven.placement")
                      ? options.required.oven.placement
                      : AUTO_SELECT_VALUE
                  }
                  onChange={(e) => {
                    if (e.target.value === AUTO_SELECT_VALUE) {
                      unlockField("oven.placement");
                      return;
                    }

                    updateRequiredAndLock("oven.placement", "oven", {
                      placement: e.target.value as "under_counter" | "column",
                    });
                  }}
                >
                  <option value={AUTO_SELECT_VALUE}>Авто</option>
                  <option value="under_counter">Под столешницей</option>
                  <option value="column">В колонне</option>
                </select>
              </label>
            </div>

            <div className="border rounded-xl p-5 space-y-3">
              <h3 className="font-semibold">Мойка</h3>

              <label className="block">
                <span className="block mb-1">Размер тумбы, мм</span>
                <select
                  className="border rounded p-2 w-full"
                  value={
                    isLocked("sink.width_mm")
                      ? options.required.sink.width_mm
                      : AUTO_SELECT_VALUE
                  }
                  onChange={(e) => {
                    if (e.target.value === AUTO_SELECT_VALUE) {
                      unlockField("sink.width_mm");
                      return;
                    }

                    updateRequiredAndLock("sink.width_mm", "sink", {
                      width_mm: Number(e.target.value),
                    });
                  }}
                >
                  <option value={AUTO_SELECT_VALUE}>Авто</option>
                  <option value={400}>400</option>
                  <option value={450}>450</option>
                  <option value={500}>500</option>
                  <option value={600}>600</option>
                  <option value={800}>800</option>
                  <option value={900}>900</option>
                  <option value={1000}>1000</option>
                  <option value={1200}>1200</option>
                </select>
              </label>
            </div>

            <div className="border rounded-xl p-5 space-y-3">
              <h3 className="font-semibold">Вытяжка</h3>

              <label className="block">
                <span className="block mb-1">Тип</span>
                <select
                  className="border rounded p-2 w-full"
                  value={
                    isLocked("hood.type")
                      ? options.required.hood.type
                      : AUTO_SELECT_VALUE
                  }
                  onChange={(e) => {
                    if (e.target.value === AUTO_SELECT_VALUE) {
                      unlockField("hood.type");
                      return;
                    }

                    const nextType = e.target.value as "built_in" | "solo";
                    const currentWidth = options.required.hood.width_mm;
                    const nextWidth = hoodPresetWidths.includes(currentWidth)
                      ? currentWidth
                      : 600;

                    updateRequiredAndLock("hood.type", "hood", {
                      type: nextType,
                      width_mm: nextWidth,
                    });
                    if (nextType === "solo") {
                      updateRoomAndLock("room.wall_cabinets_enabled", {
                        wall_cabinets_enabled: false,
                      });
                    }
                  }}
                >
                  <option value={AUTO_SELECT_VALUE}>Авто</option>
                  <option value="built_in">Встраиваемая</option>
                  <option value="solo">Соло модель</option>
                </select>
              </label>

              <label className="block">
                <span className="block mb-1">Ширина, мм</span>
                <select
                  className="border rounded p-2 w-full"
                  value={
                    isLocked("hood.width_mm")
                      ? options.required.hood.type === "solo"
                        ? hoodSelectValue
                        : String(options.required.hood.width_mm)
                      : AUTO_SELECT_VALUE
                  }
                  onChange={(e) => {
                    if (e.target.value === AUTO_SELECT_VALUE) {
                      unlockField("hood.width_mm");
                      return;
                    }

                    if (e.target.value === "custom") {
                      updateRequiredAndLock("hood.width_mm", "hood", {
                        width_mm: 1000,
                      });
                    } else {
                      updateRequiredAndLock("hood.width_mm", "hood", {
                        width_mm: Number(e.target.value),
                      });
                    }
                  }}
                >
                  <option value={AUTO_SELECT_VALUE}>Авто</option>
                  <option value={600}>600</option>
                  <option value={900}>900</option>
                  <option value={1200}>1200</option>
                  <option value={1800}>1800</option>
                  {options.required.hood.type === "solo" && (
                    <option value="custom">Свой размер</option>
                  )}
                </select>
              </label>

              {options.required.hood.type === "solo" &&
                isLocked("hood.width_mm") &&
                !hoodPresetWidths.includes(options.required.hood.width_mm) && (
                  <label className="block">
                    <span className="block mb-1">Свой размер, мм</span>
                    <input
                      type="number"
                      className="border rounded p-2 w-full"
                      value={options.required.hood.width_mm}
                      onChange={(e) =>
                        updateRequiredAndLock("hood.width_mm", "hood", {
                          width_mm: Number(e.target.value),
                        })
                      }
                    />
                  </label>
                )}
            </div>

            <div className="border rounded-xl p-5 space-y-3">
              <h3 className="font-semibold">Микроволновка</h3>

              <label className="block">
                <span className="block mb-1">Тип</span>
                <select
                  className="border rounded p-2 w-full"
                  value={
                    isLocked("microwave.type")
                      ? options.required.microwave.type
                      : AUTO_SELECT_VALUE
                  }
                  onChange={(e) => {
                    if (e.target.value === AUTO_SELECT_VALUE) {
                      unlockField("microwave.type");
                      return;
                    }

                    const nextType = e.target.value as
                      | "built_in"
                      | "upper_built_in"
                      | "solo";

                    if (nextType === "built_in" || nextType === "upper_built_in") {
                      updateRequiredAndLock("microwave.type", "microwave", {
                        type: nextType,
                        width_mm: 600,
                        height_mm: 400,
                      });
                    } else {
                      updateRequiredAndLock("microwave.type", "microwave", {
                        type: "solo",
                        width_mm: 450,
                        height_mm: 250,
                      });
                    }
                  }}
                >
                  <option value={AUTO_SELECT_VALUE}>Авто</option>
                  <option value="upper_built_in">В навесном шкафу</option>
                  <option value="built_in">В колонне</option>
                  <option value="solo">Соло</option>
                </select>
              </label>

              {isLocked("microwave.type") &&
                (options.required.microwave.type === "built_in" ||
                  options.required.microwave.type === "upper_built_in") && (
                  <label className="block">
                    <span className="block mb-1">Высота, мм</span>
                    <input
                      type="number"
                      className="border rounded p-2 w-full"
                      value={options.required.microwave.height_mm}
                      onChange={(e) =>
                        updateRequiredAndLock("microwave.height_mm", "microwave", {
                          height_mm: Number(e.target.value),
                        })
                      }
                    />
                  </label>
                )}

              {isLocked("microwave.type") && options.required.microwave.type === "solo" && (
                <div className="grid grid-cols-2 gap-3">
                  <label>
                    <span className="block mb-1">Ширина, мм</span>
                    <input
                      type="number"
                      className="border rounded p-2 w-full"
                      value={options.required.microwave.width_mm}
                      onChange={(e) =>
                        updateRequiredAndLock("microwave.width_mm", "microwave", {
                          width_mm: Number(e.target.value),
                        })
                      }
                    />
                  </label>

                  <label>
                    <span className="block mb-1">Высота, мм</span>
                    <input
                      type="number"
                      className="border rounded p-2 w-full"
                      value={options.required.microwave.height_mm}
                      onChange={(e) =>
                        updateRequiredAndLock("microwave.height_mm", "microwave", {
                          height_mm: Number(e.target.value),
                        })
                      }
                    />
                  </label>
                </div>
              )}
            </div>

            <div className="border rounded-xl p-5 space-y-3">
              <h3 className="font-semibold">Варочная панель</h3>

              <label className="block">
                <span className="block mb-1">Ширина варочной поверхности, мм</span>
                <select
                  className="border rounded p-2 w-full"
                  value={
                    isLocked("hob.cabinet_width_mm")
                      ? options.required.hob.cabinet_width_mm
                      : AUTO_SELECT_VALUE
                  }
                  onChange={(e) => {
                    if (e.target.value === AUTO_SELECT_VALUE) {
                      unlockField("hob.cabinet_width_mm");
                      return;
                    }

                    updateRequiredAndLock("hob.cabinet_width_mm", "hob", {
                      cabinet_width_mm: Number(e.target.value),
                    });
                  }}
                >
                  <option value={AUTO_SELECT_VALUE}>Авто</option>
                  <option value={300}>300</option>
                  <option value={600}>600</option>
                  <option value={800}>800</option>
                  <option value={900}>900</option>
                </select>
              </label>
            </div>
          </div>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-semibold">Необязательные элементы</h2>

          <div className="grid md:grid-cols-3 gap-4">
            <div className="border rounded-xl p-5 space-y-3">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={options.optional.dishwasher.enabled}
                  onChange={(e) => {
                    if (!e.target.checked) {
                      updateOptional("dishwasher", { enabled: false });
                      unlockField("dishwasher.width_mm");
                      return;
                    }

                    updateOptionalAndLock("dishwasher.width_mm", "dishwasher", {
                      enabled: true,
                    });
                  }}
                />
                <span className="font-semibold">Посудомоечная машина</span>
              </label>

              <label className="block">
                <span className="block mb-1">Ширина</span>
                <select
                  className="border rounded p-2 w-full"
                  value={
                    isLocked("dishwasher.width_mm")
                      ? options.optional.dishwasher.width_mm
                      : AUTO_SELECT_VALUE
                  }
                  onChange={(e) => {
                    if (e.target.value === AUTO_SELECT_VALUE) {
                      unlockField("dishwasher.width_mm");
                      return;
                    }

                    updateOptionalAndLock("dishwasher.width_mm", "dishwasher", {
                      width_mm: Number(e.target.value),
                    });
                  }}
                >
                  <option value={AUTO_SELECT_VALUE}>Авто</option>
                  <option value={600}>60 см</option>
                  <option value={450}>45 см</option>
                </select>
              </label>
            </div>

            <div className="border rounded-xl p-5">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={options.optional.undercounter_fridge.enabled}
                  onChange={(e) =>
                    updateOptional("undercounter_fridge", {
                      enabled: e.target.checked,
                    })
                  }
                />
                <span className="font-semibold">
                  Холодильник под столешницей 600 мм
                </span>
              </label>
            </div>

            <div className="border rounded-xl p-5">
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={options.optional.wine_cabinet.enabled}
                  onChange={(e) =>
                    updateOptional("wine_cabinet", {
                      enabled: e.target.checked,
                    })
                  }
                />
                <span className="font-semibold">
                  Винный шкаф под столешницей 600 мм
                </span>
              </label>
            </div>
          </div>
        </section>

        <button
          className="px-5 py-3 rounded-xl border font-semibold"
          disabled={loading}
        >
          {loading ? "Генерирую..." : "Сгенерировать кухню"}
        </button>
      </form>

      {result && (
        <section className="space-y-6">
          {result.generated_layout.warnings?.length > 0 && (
            <div className="border border-red-300 bg-red-50 p-4 rounded-xl">
              {result.generated_layout.warnings.map((warning, index) => (
                <p key={index} className="text-red-700">
                  {warning}
                </p>
              ))}
            </div>
          )}

          {result.generated_layout.size_adjustments &&
            result.generated_layout.size_adjustments.length > 0 && (
              <div className="border border-yellow-300 bg-yellow-50 p-4 rounded-xl">
                <h2 className="font-semibold mb-2">
                  Автоматически изменённые размеры
                </h2>

                <div className="space-y-1 text-sm">
                  {result.generated_layout.size_adjustments.map(
                    (adjustment, index) => (
                      <p key={index}>
                        {adjustment.label}: {renderAdjustmentValue(adjustment)}
                      </p>
                    )
                  )}
                </div>
              </div>
            )}

          <div className="border rounded-xl p-5 bg-gray-50">
            <h2 className="text-xl font-semibold mb-3">Высоты</h2>

            <div className="space-y-1 text-sm">
              <p>
                Рост заказчика:{" "}
                <span className="font-semibold">
                  {String(result.generated_layout.customer_height_cm)} см
                </span>
              </p>

              <p>
                Рекомендованная высота столешницы:{" "}
                <span className="font-semibold">
                  {String(result.generated_layout.countertop_height_mm)} мм
                </span>
              </p>

              <p>
                Цоколь:{" "}
                <span className="font-semibold">
                  {String(result.generated_layout.plinth_height_mm)} мм
                </span>
              </p>

              <p>
                Толщина столешницы:{" "}
                <span className="font-semibold">
                  {String(result.generated_layout.countertop_thickness_mm)} мм
                </span>
              </p>

              <p>
                Высота нижних модулей:{" "}
                <span className="font-semibold">
                  {String(result.generated_layout.base_module_height_mm)} мм
                </span>
              </p>

              <p>
                Формула: высота столешницы = цоколь + толщина столешницы +
                высота нижних модулей
              </p>
            </div>
          </div>

          <div className="border rounded-xl p-5">
            <h2 className="text-xl font-semibold mb-3">
              Модули слева направо
            </h2>

            <div className="space-y-2">
              {result.generated_layout.modules.map((module, index) => (
                <div key={index} className="border rounded p-3">
                  <span className="font-semibold">{String(module.name)}</span>
                  <span className="text-gray-600">
                    {" "}
                    — {String(module.width_mm)} мм, тип: {String(module.type)}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="border rounded-xl p-5">
            <h2 className="text-xl font-semibold mb-3">Top view</h2>
            <div dangerouslySetInnerHTML={{ __html: result.top_view_svg }} />
          </div>

          <div className="border rounded-xl p-5">
            <h2 className="text-xl font-semibold mb-3">Front view</h2>
            <div dangerouslySetInnerHTML={{ __html: result.front_view_svg }} />
          </div>

          {result.side_view_svg && (
            <div className="border rounded-xl p-5">
              <h2 className="text-xl font-semibold mb-3">Side view</h2>
              <div dangerouslySetInnerHTML={{ __html: result.side_view_svg }} />
            </div>
          )}

          <div className="border rounded-xl p-5">
            <h2 className="text-xl font-semibold mb-3">JSON layout</h2>
            <pre className="bg-gray-100 p-4 rounded overflow-auto text-sm">
              {JSON.stringify(result.generated_layout, null, 2)}
            </pre>
          </div>
        </section>
      )}
    </main>
  );
}
